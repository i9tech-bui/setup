ALTER TABLE document_collection
    DROP COLUMN IF EXISTS index_type;

/* Intentionally left blank as we don't want to remove an 
    embedding column that was potentially already there before the up 
*/

